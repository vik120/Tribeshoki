<?php 
/*
*   Template Name: Home Template
*
*/

?>

<?php 
    get_header();
?>

<div class="t">
    <canvas></canvas>
    <div class="t--inner">
        <img class="t--b" src="<?php bloginfo('stylesheet_directory') ?>/img/slider-bg2.jpg" alt="OkBye February 2019.">
        <img class="t--leaf l1" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <img class="t--leaf l2" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <img class="t--leaf l3" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <img class="t--leaf l4" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <img class="t--leaf l5" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <img class="t--leaf l6" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <img class="t--leaf l7" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <img class="t--leaf l8" src="<?php bloginfo('stylesheet_directory') ?>/img/leaf.png" alt="OkBye February 2019.">
        <div class="okbye">
            <?php 
                the_field('banner_title');
            ?>
        </div>
    </div>
</div>

<main class="okbye2019">
        <div class="w w_1"></div>
        <!-- carousel -->
        <section id="carousel_section" class="section0 text-white">
            <div class="border-top"></div>
            <div class="section">
                <div class="container">
                    <div class="container-heading text-center">
                        <?php the_field('second_slide_title') ?>
                        
                    </div>
                    <div id="carousel-home" class="flexslider">

                        <?php if( have_rows('second_slide_content') ): ?>

                            <ul class="slides">

                            <?php while( have_rows('second_slide_content') ): the_row(); 

                                // vars
                                $image = get_sub_field('slide_image');
                                $content = get_sub_field('slide_content');
                                $slidetitle = get_sub_field('slide_title');

                                ?>

                                <li class="carousel-item text-center">

                                    <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" />
                                    <h2 class="flexslider-title"><?php echo $slidetitle; ?></h2>
                                    <p class="flexslider-desc"> <?php echo $content; ?></p>


                                </li>

                            <?php endwhile; ?>

                            </ul>

                        <?php endif; ?>
                         
                    </div>
                </div>
            </div>
            <div class="border-bottom"></div>
        </section> 
        <!-- portfolio -->
        <section id="portfolio_section" class="section1 text-center">
            <div class="intro">
                <div class="prlx img-holder lozad"  data-image="<?php bloginfo('stylesheet_directory') ?>/img/vespa-517227_1920.jpg"></div>
                <?php the_field('third_slide_title') ?>
            </div>
            <div class="border-top"></div>
            <div class="section">
                <div class="container">
                   <?php the_field('portfolio_category') ?>

                   <?php if( have_rows('portfolio_block') ): ?>

                       <ul id="portfolio" class="grid row">

                        <?php while( have_rows('portfolio_block') ): the_row(); 

                            // vars
                            $image = get_sub_field('portfolio_image');
                            $title = get_sub_field('portfolio_title');
                            $content = get_sub_field('portfolio_content');

                        ?>

                            <li class="all portfolio-item col-md-4 col-sm-6 style <?php $portfolio_category ?>">

                                 

                                <figure class="effect-sadie"> 
                                     <img  width="400" height="300" src="<?php echo $image['url']; ?>" class="attachment-eleganto-home size-eleganto-home wp-post-image" alt="<?php echo $image['alt'] ?>" />

                                    <figcaption>
                                       
                                       <?php echo $title ?>
                                       <?php echo $content ?>
                                    </figcaption>

                                </figure>

                            </li>

                             

                        <?php endwhile; ?>

                        </ul>

                    <?php endif; ?>

                     

        </div>
    </div>
    <div class="border-bottom"></div>
</section>

<!-- Image section -->
<section id="image_section" class="section2 text-white">
    <div class="border-top"></div>
    <div class="section">
        <div class="container">
            <div class="container-heading text-center">
            </div>
            <div class="row">
                <div class="image-section-left col-md-3">
                    <?php the_field('image_section_left') ?>
                </div>
                <div class="image-section-center col-md-6">
                   <?php the_field('image_section_center') ?>
                </div>
                <div class="image-section-right col-md-3">
                   <?php the_field('image_section_right') ?>
                </div>
            </div>
        </div>
    </div>
    <div class="border-bottom"></div>
</section>

<!-- testimonial -->
<section id="testimonial_section" class="section3 text-white">
    <div class="intro">
        <div class="prlx img-holder lozad" data-image="<?php bloginfo('stylesheet_directory') ?>/img/man-489744_1920.jpg"></div>
        <h2 class="text-center"><?php the_field('happy_client_title') ?></h2>
    </div>
    <div class="border-top"></div>
    <div class="section">
        <div class="container">
            <div class="container-heading text-center">
                <h4>Testimonials</h4>
                <div class="sub-title"><span>Showcase your testimonials with style</span></div>
            </div>
            <div class="flexslider carousel slide" id="quote-carousel">

                <?php if( have_rows('client_testimonials') ): ?>

                     <ul class="slides carousel-inner text-center">

                    <?php while( have_rows('client_testimonials') ): the_row(); 

                        // vars 
                        $content = get_sub_field('client_testimonial_content'); 

                        ?>

                        

                        <li>
                            <div class="item">
                                <blockquote>
                                    <div class="row justify-content-center">
                                        <div class="col-sm-8 col-sm-offset-2">

                                            <?php echo $content ?>


                                    </div>
                                </div>
                            </blockquote>
                        </div>
                         
                    </li>

                    <?php endwhile; ?>

                    </ul>

                <?php endif; ?>

                
               
            </div>
            
        </div>
    </div>
    <div class="border-bottom"></div>
</section>

<!-- contact -->

<section id="contact_section" class="section5 text-white">
    <div class="intro">
        <?php the_field('contact_section') ?>
       
    </div>
    <div class="border-top"></div>
    <div class="section">
        <div class="container">
            <div class="container-heading text-center">
                <?php the_field('contact_title') ?>
               
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <?php the_field('contact_form') ?>
                </div>
                <div class="col-sm-4">
                    <p class="about-us">
                        <?php the_field('about_us') ?>
                       

                </div>
            </div>
            <!--/row-->
        </div>
    </div>
    <div class="border-bottom"></div>
</section>

<section style="height: 500px; background: #000" class="section5">
     
    
</section>

</main>
<footer class="f">
    <?php if ( get_theme_mod( 'eleganto_socials', 0 ) == 1 ) : ?>
        <div class="footer-socials text-center">
            <?php
            if ( get_theme_mod( 'eleganto_socials', 0 ) == 1 ) {
                eleganto_social_links();
            }
            ?>                 
        </div>
    <?php endif; ?>
</footer>
<div class="bg"></div>



<?php 
    get_footer();
?>